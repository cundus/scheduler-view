export const COLOR = {
   BLACK: "#000",
   DARK_BG: "#2C3333",
   LIGHT_BG: "#CBE4DE",
   CONTENT: "#0E8388",
};
